const fs = require('fs')
const chalk = require('chalk')
const moment = require('moment-timezone')

global.owner = "14314009636"

global.ThM = "https://files.catbox.moe/kryeiw.jpeg"
global.imgreply = "https://files.catbox.moe/kryeiw.jpeg"
global.thumb = "https://files.catbox.moe/kryeiw.jpeg"

global.msg = {
    done: 'selesai',
    wait: 'wait a minute',
    admin: 'admin only',
    adminbot: 'bot admin only',
    owner: 'owner only',
    group: 'group only',
    private: 'private only',
    bot: 'bot only',
    wait: 'wait a minute',
    endLimit: 'limit kamu habis',
    error: 'terjadi error',
    prem: 'premium only',
    developer: 'developer only'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})
