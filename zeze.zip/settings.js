const fs = require('fs')
global.prefa = [''] 
global.botname = "⨭͛͠𝐙𝐄̶͓𝐃̷𝐄͡𝐙͍̽𝐀͡𝐃𝐀̚"
global.version = "1"
global.owner = "14314009636"
global.title = "Keluarga Halilintar"
global.website = "whatsapp.com/channel"
global.idch = "120363417139133123@newsletter"
global.chjid = "https://whatsapp.com/channel"
global.wm = ""
//===================================//
global.session = "session"
//=========== [ IMG-URL ] ===========//
global.thumb = "https://files.catbox.moe/cfkh9x.jpg"
global.image = {
Reply: "https://files.catbox.moe/cfkh9x.jpg"
}
//==================================//
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
